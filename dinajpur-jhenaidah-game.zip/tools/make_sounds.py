#!/usr/bin/env python3
# Generates original sound effects (no copyright) into ../audio/*.wav. Run: python3 tools/make_sounds.py
import wave, struct, math, random, os
SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
os.makedirs(OUT, exist_ok=True)
random.seed(7)

def write(name, x):
    peak = max(0.001, max(abs(s) for s in x))
    k = min(1.0, 0.9 / peak) if peak > 0.9 else 1.0
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s * k)) * 32000)) for s in x))

def tone(f, d, vol=0.5, decay=4.0, harm=((1, 1.0),)):
    n = int(SR * d)
    return [vol * math.exp(-decay * i / n) * sum(a * math.sin(2 * math.pi * f * h * i / SR) for h, a in harm) for i in range(n)]

def mix(parts, total):
    out = [0.0] * int(SR * total)
    for off, x in parts:
        o = int(SR * off)
        for i, s in enumerate(x):
            if o + i < len(out): out[o + i] += s
    return out

def lowpass(x, a):
    y, p = [], 0.0
    for s in x:
        p += a * (s - p); y.append(p)
    return y

def noise(d): return [random.uniform(-1, 1) for _ in range(int(SR * d))]

# coin: bright two-note ping
write("coin", mix([(0, tone(988, .1, .5, 6, ((1, 1), (2, .3)))), (.08, tone(1319, .35, .5, 5, ((1, 1), (2, .3))))], .45))
# jump: rising sweep
n = int(SR * .2); ph = 0; j = []
for i in range(n):
    t = i / n; ph += 2 * math.pi * (300 + 500 * t) / SR; j.append(.5 * math.sin(ph) * (1 - t) ** .5)
write("jump", j)
# crash: noise burst + low thump
cr = lowpass(noise(.6), .25)
write("crash", [s * math.exp(-5 * i / len(cr)) * 1.6 + t for i, (s, t) in enumerate(zip(cr, tone(60, .6, .7, 6)))])
# powerup: arpeggio
write("powerup", mix([(k * .09, tone(f, .25, .4, 5, ((1, 1), (2, .25)))) for k, f in enumerate([523, 659, 784, 1047])], .6))
# love: soft sweet chime (E5 G5 B5 E6) with shimmer
write("love", mix([(k * .16, tone(f, .9, .35, 3, ((1, 1), (2, .4), (3, .15)))) for k, f in enumerate([659, 784, 988, 1319])], 1.3))
# rain loop
r = noise(3.0); lp = lowpass(r, .08)
write("rain", [(a - b) * .55 for a, b in zip(r, lp)])
# thunder: crack + long rumble
th = lowpass(noise(4.0), .03); N = len(th)
rumble = [th[i] * 14 * min(1, i / (SR * .15)) * math.exp(-.9 * i / SR) * (.65 + .35 * math.sin(2 * math.pi * 3 * i / SR + 1.3)) for i in range(N)]
crack = [s * math.exp(-18 * i / SR) * .6 for i, s in enumerate(noise(.5))]
write("thunder", mix([(0, rumble), (0, crack)], 4.0))
# tiger growl
d = 1.4; N = int(SR * d); nz = lowpass(noise(d), .15); g = []
for i in range(N):
    t = i / SR; f = 80 + 12 * math.sin(2 * math.pi * 5 * t)
    saw = 2 * ((f * t) % 1) - 1
    g.append((saw * .5 + nz[i] * 1.5) * (.6 + .4 * math.sin(2 * math.pi * 28 * t)) * math.sin(math.pi * i / N) ** .6)
write("tiger", g)
# horn: two-tone
d = .7; N = int(SR * d)
write("horn", [(math.copysign(1, math.sin(2 * math.pi * 392 * i / SR)) * .15 + math.sin(2 * math.pi * 392 * i / SR) * .25 +
                math.sin(2 * math.pi * 494 * i / SR) * .25) * min(1, i / 800, (N - i) / 2000) for i in range(N)])
# music: 9.6s pentatonic loop
sc = [293.66, 329.63, 369.99, 440, 493.88, 587.33]
pat = [0, 2, 3, 2, 4, 3, 2, 1, 0, 2, 3, 5, 4, 3, 2, 3, 1, 2, 3, 4, 5, 4, 3, 2, 3, 2, 1, 0, 1, 2, 1, 0]
step = .3; parts = []
for k, ix in enumerate(pat):
    parts.append((k * step, tone(sc[ix], .55, .22, 3, ((1, 1), (2, .3)))))
    if k % 4 == 0:
        parts.append((k * step, tone(73.42 if (k // 4) % 2 == 0 else 110, 1.2, .25, 2.0, ((1, 1), (2, .2)))))
write("music", mix(parts, step * len(pat)))
print("sounds written to", os.path.abspath(OUT))
