#!/usr/bin/env python3
"""Generates textures/grass.png (tileable). Run: python3 tools/make_textures.py (needs Pillow)"""
import os, random, math
from PIL import Image, ImageDraw, ImageFilter
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "textures"); os.makedirs(OUT, exist_ok=True)
random.seed(11); N = 256
def wrap_noise(cells):
    g = [[random.random() for _ in range(cells)] for _ in range(cells)]
    im = Image.new("L", (N, N))
    for y in range(N):
        for x in range(N):
            fx, fy = x / N * cells, y / N * cells; x0, y0 = int(fx), int(fy); tx, ty = fx - x0, fy - y0
            a, b = g[y0 % cells][x0 % cells], g[y0 % cells][(x0 + 1) % cells]; c, d = g[(y0 + 1) % cells][x0 % cells], g[(y0 + 1) % cells][(x0 + 1) % cells]
            im.putpixel((x, y), int(255 * ((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty)))
    return im
low, mid = wrap_noise(4), wrap_noise(16)
img = Image.new("RGB", (N, N))
for y in range(N):
    for x in range(N):
        v = low.getpixel((x, y)) / 255 * .5 + mid.getpixel((x, y)) / 255 * .5; n = random.uniform(-.08, .08)
        img.putpixel((x, y), (int(70 + 40 * v + 30 * n), int(120 + 60 * v + 40 * n), int(48 + 24 * v + 20 * n)))
d = ImageDraw.Draw(img)
for _ in range(1800):
    x, y = random.randrange(N), random.randrange(N); l = random.randint(3, 8); c = random.choice([(40, 95, 36), (110, 170, 60), (88, 150, 50)])
    for ox in (-N, 0, N):
        for oy in (-N, 0, N): d.line([(x + ox, y + oy), (x + ox + random.randint(-2, 2), y + oy - l)], fill=c, width=1)
img.save(os.path.join(OUT, "grass.png")); print("textures written")
