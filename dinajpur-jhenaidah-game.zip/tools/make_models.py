#!/usr/bin/env python3
"""Generates .glb models (10 characters + road segment) into ../models. Run: python3 tools/make_models.py
These are low-poly placeholders that follow the game's naming convention. Replace any file with a real
glb of the same name (see README) and the game will use it automatically."""
import struct, json, math, zlib, os, random
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "models")
random.seed(3)

def box(sx, sy, sz):
    h = (sx / 2, sy / 2, sz / 2)
    faces = [((1,0,0),(0,1,0),(0,0,1)), ((-1,0,0),(0,0,1),(0,1,0)), ((0,1,0),(0,0,1),(1,0,0)),
             ((0,-1,0),(1,0,0),(0,0,1)), ((0,0,1),(1,0,0),(0,1,0)), ((0,0,-1),(0,1,0),(1,0,0))]
    V, N, UV, I = [], [], [], []
    for n, u, v in faces:
        eu = abs(sum(u[i] * h[i] for i in range(3))); ev = abs(sum(v[i] * h[i] for i in range(3)))
        c = [n[i] * h[i] for i in range(3)]
        base = len(V)
        for su, sv, a, b in [(-1,-1,0,0),(1,-1,1,0),(1,1,1,1),(-1,1,0,1)]:
            V.append(tuple(c[i] + su * eu * u[i] + sv * ev * v[i] for i in range(3)))
            N.append(n); UV.append((a * 2 * eu * .25, b * 2 * ev * .25))
        I += [base, base+1, base+2, base, base+2, base+3]
    return V, N, UV, I

def lathe(profile, seg=14):
    V, N, UV, I = [], [], [], []
    for (r, y, nr, ny) in profile:
        for j in range(seg + 1):
            a = 2 * math.pi * j / seg
            V.append((r * math.cos(a), y, r * math.sin(a))); N.append((nr * math.cos(a), ny, nr * math.sin(a))); UV.append((j / seg, y))
    S = seg + 1
    for i in range(len(profile) - 1):
        for j in range(seg):
            a, b, c, d = i*S+j, (i+1)*S+j, (i+1)*S+j+1, i*S+j+1
            I += [a, b, c, a, c, d]
    return V, N, UV, I

def sphere(R, rings=10):
    return lathe([(R*math.sin(math.pi*k/rings), -R*math.cos(math.pi*k/rings), math.sin(math.pi*k/rings), -math.cos(math.pi*k/rings)) for k in range(rings+1)])

def capsule(R, H, rings=5):
    L = max(H - 2*R, 0.0); p = []
    for k in range(rings + 1):
        t = (math.pi / 2) * k / rings
        p.append((R*math.sin(t), -L/2 - R*math.cos(t), math.sin(t), -math.cos(t)))
    for k in range(rings + 1):
        t = math.pi/2 + (math.pi / 2) * k / rings
        p.append((R*math.sin(t), L/2 - R*math.cos(t), math.sin(t), -math.cos(t)))
    return lathe(p)

def cylinder(rt, rb, h):
    L = math.hypot(rt - rb, h); nr, ny = h / L, (rb - rt) / L
    return lathe([(0,-h/2,0,-1),(rb,-h/2,0,-1),(rb,-h/2,nr,ny),(rt,h/2,nr,ny),(rt,h/2,0,1),(0,h/2,0,1)])

def qx(deg):
    a = math.radians(deg) / 2; return (math.sin(a), 0, 0, math.cos(a))

class GLB:
    def __init__(s):
        s.bin = bytearray(); s.bv = []; s.acc = []; s.meshes = []; s.mats = []; s.mk = {}; s.nodes = []; s.imgs = []; s.tex = []
    def _view(s, data, target=None):
        while len(s.bin) % 4: s.bin.append(0)
        d = {"buffer": 0, "byteOffset": len(s.bin), "byteLength": len(data)}
        if target: d["target"] = target
        s.bin += data; s.bv.append(d); return len(s.bv) - 1
    def _acc(s, view, ct, count, typ, mn=None, mx=None):
        a = {"bufferView": view, "componentType": ct, "count": count, "type": typ}
        if mn is not None: a["min"] = mn; a["max"] = mx
        s.acc.append(a); return len(s.acc) - 1
    def image(s, png):
        v = s._view(png); s.imgs.append({"bufferView": v, "mimeType": "image/png"})
        s.tex.append({"source": len(s.imgs) - 1, "sampler": 0}); return len(s.tex) - 1
    def material(s, name, rgb, rough=0.85, tex=None):
        key = (name, tuple(rgb), tex)
        if key in s.mk: return s.mk[key]
        pbr = {"baseColorFactor": [rgb[0], rgb[1], rgb[2], 1.0], "metallicFactor": 0.0, "roughnessFactor": rough}
        if tex is not None: pbr["baseColorTexture"] = {"index": tex}
        s.mats.append({"name": name, "pbrMetallicRoughness": pbr}); s.mk[key] = len(s.mats) - 1; return s.mk[key]
    def part(s, name, geom, mat, t=None, q=None, sc=None):
        V, N, UV, I = geom
        pv = b"".join(struct.pack("<3f", *p) for p in V); nv = b"".join(struct.pack("<3f", *p) for p in N)
        uv = b"".join(struct.pack("<2f", *p) for p in UV); iv = b"".join(struct.pack("<I", i) for i in I)
        mn = [min(p[i] for p in V) for i in range(3)]; mx = [max(p[i] for p in V) for i in range(3)]
        a0 = s._acc(s._view(pv, 34962), 5126, len(V), "VEC3", mn, mx); a1 = s._acc(s._view(nv, 34962), 5126, len(V), "VEC3")
        a2 = s._acc(s._view(uv, 34962), 5126, len(V), "VEC2"); a3 = s._acc(s._view(iv, 34963), 5125, len(I), "SCALAR")
        s.meshes.append({"primitives": [{"attributes": {"POSITION": a0, "NORMAL": a1, "TEXCOORD_0": a2}, "indices": a3, "material": mat}]})
        return s.node(name, len(s.meshes) - 1, t, q, sc)
    def node(s, name, mesh=None, t=None, q=None, sc=None, ch=None):
        n = {"name": name}
        if mesh is not None: n["mesh"] = mesh
        if t is not None and any(t): n["translation"] = list(t)
        if q: n["rotation"] = list(q)
        if sc: n["scale"] = list(sc)
        if ch: n["children"] = ch
        s.nodes.append(n); return len(s.nodes) - 1
    def save(s, path, roots):
        j = {"asset": {"version": "2.0", "generator": "make_models.py"}, "scene": 0, "scenes": [{"nodes": roots}], "nodes": s.nodes,
             "meshes": s.meshes, "materials": s.mats, "accessors": s.acc, "bufferViews": s.bv, "buffers": [{"byteLength": len(s.bin)}]}
        if s.imgs:
            j["images"] = s.imgs; j["textures"] = s.tex
            j["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        js = json.dumps(j, separators=(",", ":")).encode(); js += b" " * ((4 - len(js) % 4) % 4)
        b = bytes(s.bin) + b"\0" * ((4 - len(s.bin) % 4) % 4)
        data = struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(js) + 8 + len(b)) + struct.pack("<I4s", len(js), b"JSON") + js + struct.pack("<I4s", len(b), b"BIN\0") + b
        os.makedirs(os.path.dirname(path), exist_ok=True); open(path, "wb").write(data)

def character(d, path):
    g = GLB(); M = lambda nm, c, r=0.8: g.material(nm, c, r)
    skin, shirt, pants, hair, shoes = d["skin"], d["shirt"], d["pants"], d["hair"], d["shoes"]
    outfit, style = d.get("outfit", "pants"), d.get("hair_style", "short")
    ch = []; P = lambda *a, **k: ch.append(g.part(*a, **k))
    P("Torso", capsule(0.3, 1.0), M("shirt", shirt), (0, 1.15, 0), sc=(1, 1, 0.7))
    P("Head", sphere(0.26), M("skin", skin, 0.6), (0, 1.84, 0))
    P("Nose", sphere(0.04), M("skin", skin, 0.6), (0, 1.8, -0.26))
    for s in (-1, 1):
        P("Eye", sphere(0.045), M("white", (1, 1, 1), 0.3), (s * 0.1, 1.88, -0.23))
        P("Pupil", sphere(0.025), M("dark", (0.05, 0.05, 0.05), 0.3), (s * 0.1, 1.88, -0.27))
    P("Hair", sphere(0.285), M("hair", hair, 0.55), (0, 1.93, 0.04), sc=(1, 0.8, 1))
    if style == "long": P("HairLong", capsule(0.17, 0.75), M("hair", hair, 0.55), (0, 1.6, 0.2))
    elif style == "ponytail": P("Ponytail", capsule(0.07, 0.55), M("hair", hair, 0.55), (0, 1.8, 0.33), q=qx(-35))
    elif style == "bun": P("Bun", sphere(0.13), M("hair", hair, 0.55), (0, 2.18, 0.05))
    elif style == "cap":
        cc = d.get("cap", shirt)
        P("CapDome", sphere(0.3), M("cap", cc), (0, 1.97, 0.02), sc=(1, 0.65, 1)); P("CapBrim", box(0.3, 0.03, 0.22), M("cap", cc), (0, 1.93, -0.32))
    if outfit == "dress": P("Dress", cylinder(0.22, 0.45, 0.6), M("shirt", shirt), (0, 0.82, 0))
    elif outfit == "panjabi": P("Panjabi", cylinder(0.3, 0.37, 0.95), M("shirt", shirt), (0, 0.95, 0))
    for s, nm in ((-1, "L"), (1, "R")):
        leg = [g.part("Leg", capsule(0.1, 0.78), M("pants", pants), (0, -0.38, 0)), g.part("Shoe", box(0.2, 0.12, 0.34), M("shoes", shoes), (0, -0.74, -0.05))]
        ch.append(g.node("Leg" + nm, None, (s * 0.15, 0.78, 0), ch=leg))
    for s, nm in ((-1, "L"), (1, "R")):
        arm = [g.part("Arm", capsule(0.075, 0.66), M("skin", skin, 0.6), (0, -0.3, 0)), g.part("Hand", sphere(0.09), M("skin", skin, 0.6), (0, -0.64, 0))]
        ch.append(g.node("Arm" + nm, None, (s * 0.4, 1.5, 0), ch=arm))
    root = g.node("Character", ch=ch); g.save(path, [root])

def png(w, h, px):
    raw = b"".join(b"\0" + bytes(c for x in range(w) for c in px[y][x]) for y in range(h))
    def chunk(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")

def asphalt_png(n=256):
    # 8 m tile. v (columns) maps x = v*8 - 3.8 ; wheel tracks of the 3 lanes are darker/smoother.
    px = [[None] * n for _ in range(n)]
    low = [[random.uniform(-9, 9) for _ in range(8)] for _ in range(8)]
    tracks = [-2.9, -1.5, -0.7, 0.7, 1.5, 2.9]
    for y in range(n):
        for x in range(n):
            xm = x / n * 8 - 3.8
            v = 66 + low[y * 8 // n][x * 8 // n] + random.uniform(-13, 13)
            for t in tracks: v -= 9 * math.exp(-((xm - t) / 0.22) ** 2)
            if random.random() < 0.025: v += random.uniform(25, 60)
            px[y][x] = v
    for _ in range(7):  # cracks
        x, y = random.randrange(n), random.randrange(n)
        for _ in range(random.randint(25, 70)):
            x = (x + random.choice((-1, 0, 1))) % n; y = (y + random.choice((0, 1, 1))) % n; px[y][x] -= 38
    for _ in range(4):  # patches / oil stains
        cx, cy, r = random.randrange(n), random.randrange(n), random.randint(8, 22)
        for y in range(cy - r, cy + r):
            for x in range(cx - r, cx + r):
                if (x - cx) ** 2 + (y - cy) ** 2 < r * r: px[y % n][x % n] -= 14
    img = [[(int(max(18, min(150, v))),) * 2 + (int(max(18, min(150, v))) + 3,) for v in row] for row in px]
    return png(n, n, img)

def road(path, kind):
    g = GLB(); tex = g.image(asphalt_png()); ch = []
    asph = g.material("asphalt", (1, 1, 1), 0.9, tex); white = g.material("paint", (0.9, 0.9, 0.84), 0.75)
    yellow = g.material("paint_y", (0.9, 0.72, 0.15), 0.75)
    asphalt_geom = box(7.6, 0.12, 40)
    asphalt_geom = (asphalt_geom[0], asphalt_geom[1], [(u / 2, v / 2) for u, v in asphalt_geom[2]], asphalt_geom[3])  # 0.125 uv per metre
    ch.append(g.part("Asphalt", asphalt_geom, asph, (0, -0.04, -20)))
    for x in (-1.1, 1.1):
        for k in range(5): ch.append(g.part("Dash", box(0.12, 0.01, 2.4), white, (x, 0.025, -4 - 8 * k)))
    for x in (-3.55, 3.55): ch.append(g.part("Edge", box(0.14, 0.01, 40), white, (x, 0.025, -20)))
    if kind == "city":
        kerb = g.material("kerb", (0.66, 0.66, 0.63), 0.9); walk = g.material("sidewalk", (0.56, 0.54, 0.5), 0.9)
        for s in (-1, 1):
            ch.append(g.part("Kerb", box(0.4, 0.27, 40), kerb, (s * 4.0, 0.035, -20)))
            ch.append(g.part("Sidewalk", box(1.2, 0.27, 40), walk, (s * 4.8, 0.035, -20)))
        for s in (-1, 1):
            for k in range(8): ch.append(g.part("Zebra", box(0.3, 0.012, 0.01), white, (s * 3.0, 0.03, -2 - 5 * k)))
    else:
        dirt = g.material("dirt", (0.46, 0.35, 0.22), 0.98); grass = g.material("verge", (0.32, 0.5, 0.2), 0.98)
        for s in (-1, 1):
            ch.append(g.part("Shoulder", box(1.0, 0.11, 40), dirt, (s * 4.3, -0.04, -20)))
            ch.append(g.part("Verge", box(0.6, 0.1, 40), grass, (s * 5.1, -0.045, -20)))
            for k in range(10): ch.append(g.part("Post", box(0.1, 0.55, 0.1), white, (s * 3.95, 0.25, -2 - 4 * k)))
    g.save(path, [g.node("Road_" + kind, ch=ch)])

if __name__ == "__main__":
    chars = json.load(open(os.path.join(HERE, "..", "data", "characters.json"), encoding="utf-8"))
    for c in chars: character(c, os.path.join(OUT, "characters", c["id"] + ".glb"))
    road(os.path.join(OUT, "road", "road_village.glb"), "village")
    road(os.path.join(OUT, "road", "road_city.glb"), "city")
    print("models written to", os.path.abspath(OUT))
