extends Node
# Optional cloud backup. Game works fully offline; this only runs when pressed.
# Set a URL (Firebase/Supabase/own server) that accepts PUT (save) and GET (restore) of a JSON body.
var status := "ক্লাউড URL সেট করা হয়নি"

func _url() -> String:
	return str(Game.save["settings"].get("cloud_url", ""))

func sync() -> void:
	if _url() == "":
		status = "ক্লাউড URL সেট করা হয়নি (লোকাল সেভ নিরাপদ আছে)"
		return
	Game.write_save()
	var http := HTTPRequest.new()
	add_child(http)
	var err := http.request(_url(), ["Content-Type: application/json"], HTTPClient.METHOD_PUT, JSON.stringify(Game.save))
	if err != OK:
		status = "ইন্টারনেট সমস্যা"
		http.queue_free()
		return
	var res: Array = await http.request_completed
	status = "সিঙ্ক সফল" if int(res[1]) in [200, 201, 204] else "সিঙ্ক ব্যর্থ (%s)" % str(res[1])
	http.queue_free()

func restore() -> void:
	if _url() == "":
		status = "ক্লাউড URL সেট করা হয়নি"
		return
	var http := HTTPRequest.new()
	add_child(http)
	if http.request(_url()) != OK:
		status = "ইন্টারনেট সমস্যা"
		http.queue_free()
		return
	var res: Array = await http.request_completed
	var d: Variant = JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())
	if int(res[1]) == 200 and d is Dictionary and d.has("coins"):
		Game.save.merge(d, true)
		Game.write_save()
		status = "ক্লাউড থেকে রিস্টোর হয়েছে"
	else:
		status = "রিস্টোর ব্যর্থ"
	http.queue_free()
